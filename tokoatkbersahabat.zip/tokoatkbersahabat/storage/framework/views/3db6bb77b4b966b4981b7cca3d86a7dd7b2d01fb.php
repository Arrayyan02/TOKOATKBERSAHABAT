<!DOCTYPE html>
<html>
<head>
    <title>User Dashboard</title>
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
    <div class="container mt-5">
        <h1>Welcome to User Dashboard</h1>
        <p>You are logged in as a regular user.</p>
    </div>
</body>
</html>
<?php /**PATH C:\Users\Ryan\login\resources\views/dashboard.blade.php ENDPATH**/ ?>