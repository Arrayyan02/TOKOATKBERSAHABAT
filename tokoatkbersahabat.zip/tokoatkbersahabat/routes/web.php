<?php

use App\Http\Controllers\ProfileController;
use Illuminate\Support\Facades\Route;
use App\Http\Controllers\AdminController;
use App\Http\Controllers\AuthController;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('welcome');
});

Route::get('register', [AuthController::class, 'showRegistrationForm'])->name('register');
Route::post('register', [AuthController::class, 'register']);

Route::get('login', [AuthController::class, 'showLoginForm'])->name('login');
Route::post('login', [AuthController::class, 'login']);

Route::post('/logout', [AuthController::class, 'logout'])->name('logout');

Route::get('/user/profile', [UserController::class, 'profile'])->name('user.profile');


Route::middleware(['auth', 'admin'])->group(function () {
    Route::get('/admin/dashboard', [AdminController::class, 'index'])->name('admin.dashboard');
    Route::get('/admin/users/{id}/edit', [AdminController::class, 'editUser'])->name('admin.users.edit');
    Route::get('/admin/users', [AdminController::class, 'listUsers'])->name('admin.users');
    Route::put('/admin/users/{id}', [AdminController::class, 'updateUser'])->name('admin.users.update');
    Route::delete('/admin/users/{id}', [AdminController::class, 'deleteUser'])->name('admin.users.delete');
});

Route::middleware(['auth'])->group(function () {
    Route::get('/dashboard', [AuthController::class, 'dashboard'])->name('dashboard');
    Route::get('/admin/dashboard', [AuthController::class, 'adminDashboard'])->name('admin.dashboard');
});


Route::middleware(['auth'])->group(function () {
    Route::get('profile', [ProfileController::class, 'show'])->name('profile.show');
    Route::get('profile/edit', [ProfileController::class, 'edit'])->name('profile.edit');
    Route::post('profile/update', [ProfileController::class, 'update'])->name('profile.update');
});


// Route::middleware(['auth', 'admin'])->group(function () {
//     Route::get('/admin/users', [AdminController::class, 'listUsers'])->name('admin.users');
//     Route::get('/admin/users/{id}/edit', [AdminController::class, 'editUser'])->name('admin.editUser');
//     Route::delete('/admin/users/{id}', [AdminController::class, 'deleteUser'])->name('admin.deleteUser');
// });




// Route::middleware(['auth', 'check.owner'])->group(function () {
//     Route::get('/admin/users/edit/{id}', [AdminController::class, 'edit'])->name('admin.users.edit');
//     Route::post('/admin/users/update/{id}', [AdminController::class, 'update'])->name('admin.users.update');
//     Route::delete('/admin/users/delete/{id}', [AdminController::class, 'delete'])->name('admin.users.delete');
// });

// Route::middleware('auth')->group(function () {
//     Route::get('/dashboard', 'AuthController@index')->name('dashboard');
//     // Tambahkan route lain yang ingin Anda proteksi di sini
// });

